  ______ _____  _____ _    ___      ________   _________ 
 |  ____|_   _|/ ____| |  | \ \    / / __ \ \ / /__   __|
 | |__    | | | (___ | |__| |\ \  / / |  | \ V /   | |   
 |  __|   | |  \___ \|  __  | \ \/ /| |  | |> <    | |   
 | |     _| |_ ____) | |  | |  \  / | |__| / . \   | |   
 |_|    |_____|_____/|_|  |_|   \/   \____/_/ \_\  |_|   2023-2024
                                                         
以下使用条款在将来可能会发生变化，请以最新版本为准。请关注条款内容的变化。

The following terms might change in the future, the lastest version shall prevail.
Please be aware to the changes in the future.

作者：鱼摆摆不咕咕
团队：VOXT PBR

AUTHOR: FISHbai
TEAM: VOXT PBR Team

在开始使用前，请阅读本说明并且遵守条款。否则我们有权采取法律行动。

Please read this instruction and comply with the terms and conditions
before you start using them. Otherwise, we have the right to take legal action.

︎●当您购买了本作品，你可以进行以下行为：
1.你可以将其装载在你的移动设备上，并对其体验
2.你可以在游玩过程中进行游玩录制，但需要标注本作品名称，作者
3.你可以私自改包供自己游玩，以适应您的审美
4.你可以将此包运用在任何地方，只要标注本作品名称即可

︎●当您购买了本作品，你不可以进行以下行为：
1.你不可以将此包进行修改后二次发布
2.你不可以直接将此包分发给他人
3.你创作视频，周边等使用本材质时不标注名称
4.你不可以不付费

如果你想要分享本材质包，请分享爱发电链接 https://afdian.net/a/fishpbr
未经过作者许可严禁将此包外传。

When you purchase this work, you can take the following actions:
1. You can load it on your mobile device and experience it
2. You can record the game while playing, but you need to indicate the name of the work and the author
3. You can privately change the package for your own play to adapt to your aesthetic preferences
4. You can use this package anywhere as long as you label the name of your work

When you purchase this work, you are not allowed to:
1. You cannot modify this package and publish it again
2. You cannot directly distribute this package to others
3. When you create videos, do not label the surrounding materials with names when using this material
4. You can't do it without paying

If you want to share this material pack,
 please share the Love Power link https://afdian.net/a/fishpbrIt is strictly prohibited to share this package without the author's permission.

